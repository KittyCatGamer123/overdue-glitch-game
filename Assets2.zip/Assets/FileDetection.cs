using UnityEngine;
using UnityEngine.Events;

public class FileDetection : MonoBehaviour
{
    public GameObject File;
    public UnityEvent enteredTrigger;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public void OnTriggerEnter2D(Collider other)
    {
        
    }

    void OnCollisionEnter2D(Collision2D coll)
    {
        // If the Collider2D component is enabled on the collided object
        if (coll.collider == true)
        {
            // Disables the Collider2D component
            Debug.Log("Collided");
        }
    }
}
