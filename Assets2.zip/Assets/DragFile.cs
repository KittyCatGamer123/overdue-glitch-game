using UnityEngine;
using UnityEngine.InputSystem;

public class DragFile : MonoBehaviour
{
    private Transform dragging = null;
    private Vector3 offset;

    void Start()
    {
        
    }

    void Update()
    {
        Vector3 mouseScreenPos = Mouse.current.position.ReadValue();
        Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(mouseScreenPos);
        mouseWorldPos.z = 0f;

        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            RaycastHit2D hit = Physics2D.Raycast(mouseWorldPos, Vector2.zero);
            if (hit)
            {
                dragging = hit.transform;
                offset = dragging.position - mouseWorldPos;
            }
        }
        else if (Mouse.current.leftButton.wasReleasedThisFrame)
        {
            dragging = null;
        }

        if (dragging != null)
        {
            dragging.position = mouseWorldPos + offset;
        }
    }
}