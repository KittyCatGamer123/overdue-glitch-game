using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;

public class WebScript : MonoBehaviour
{
    public GameObject window;
    int pos = 0;
    void Start()
    {
        pos = (int)(transform.position.x + 2);
    }
    
    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);
            
            if (hit.collider != null && hit.collider.gameObject == gameObject)
            {
                Vector3 spawnpos = new Vector3(pos, 1, 0);
                GameObject spawned = Instantiate(window, spawnpos, transform.rotation);
                spawned.GetComponentInChildren<Close>().spawner = this;
            }
        }
    }
}
