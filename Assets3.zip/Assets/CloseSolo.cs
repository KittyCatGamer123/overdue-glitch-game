using UnityEngine;
using UnityEngine.InputSystem;

public class CloseSolo : MonoBehaviour
{
    public GameObject self;
    public GameObject virus;

    void Start()
    {
        virus = GameObject.Find("Virus");
    }

    void Update()
    {
        virus.GetComponent<Virus>().close = self;
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

            if (hit.collider != null && hit.collider.gameObject == gameObject)
            {
                GameObject.Destroy(self);
            }
        }
    }
}