using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;

public class WebScript : MonoBehaviour
{
    public GameObject window;
    public GameObject popup;
    public int tabs;
    int iterationCount = 4;
    int windowLayer = 5;
    Vector3 spawnpos = new Vector3(0,0,0);
    

    void Start()
    {
        tabs = 0;
    }

    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);
            
            if (hit.collider != null && hit.collider.gameObject == gameObject)
            {
                tabs = 0;
                GameObject spawned1 = Instantiate(window, spawnpos, transform.rotation);
                spawned1.GetComponentInChildren<Download>().close = this;

                for (int i = 0; i < iterationCount; i++)
                {
                    Vector3 spawnpos = new Vector3(Random.Range(-4,4), Random.Range(-3,3), 0);
                    Debug.Log("Clicked");
                    window.layer = windowLayer;
                    windowLayer = windowLayer+1;
                    GameObject spawned = Instantiate(popup, spawnpos, transform.rotation);
                    spawned.GetComponentInChildren<Close>().spawner = this;
                }
                windowLayer = 5;
            }
        }
    }

    public void OnWindowDestroyed(bool countTab = true)
    {
        if (countTab)
        {
            tabs = tabs +1;
        }

    }
}
