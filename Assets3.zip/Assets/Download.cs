using UnityEngine;
using UnityEngine.InputSystem;

public class Download : MonoBehaviour
{
    public GameObject loading;
    public GameObject error;
    public WebScript close;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

            if (hit.collider != null && hit.collider.gameObject == gameObject)
            {
                Vector3 origin = new Vector3 (0,0,0);
                if (close.tabs < 4)
                {
                    Instantiate(error, origin, transform.rotation);
                }
                 if (close.tabs >= 4)
                {
                    Instantiate(loading, origin, transform.rotation);
                }
            }
        }
    }
}
