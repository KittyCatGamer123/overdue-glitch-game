using UnityEngine;

public class Virus : MonoBehaviour
{
    public GameObject close;
    public float speed = 5f;

    void Start()
    {
        
    }

    void Update()
    {
        if (close != null)
        {
            Vector3 direction = (close.transform.position - transform.position).normalized;
            transform.position += direction * speed * Time.deltaTime;
        }
    }
}