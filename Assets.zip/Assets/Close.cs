using UnityEngine;
using UnityEngine.InputSystem;

public class Close : MonoBehaviour
{
    public GameObject self;
    public WebScript spawner;

    void Start()
    {
        
    }

    void Update()
    {
        if (spawner == null) return;
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

            if (hit.collider != null && hit.collider.gameObject == gameObject)
            {
                spawner.OnWindowDestroyed();
                GameObject.Destroy(self);
            }
        }
    }
}