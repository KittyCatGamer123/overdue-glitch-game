using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;

public class SaveScript : MonoBehaviour
{
    public GameObject loadingBar;
    public GameObject errorWindow;
    public WebScript close;
    Vector3 spawnpos = new Vector3(0, 0, 0);
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

            if (hit.collider != null && hit.collider.gameObject == gameObject)
            {
                if (close.tabs < 4)
                {
                    GameObject spawned = Instantiate(errorWindow, spawnpos, transform.rotation);
                    spawned.GetComponentInChildren<Close1>().spawner = close;
                }
                 if (close.tabs >= 4)
                {
                    Instantiate(loadingBar, spawnpos, transform.rotation);
                }
            }
        }
    }
}
